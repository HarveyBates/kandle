*PADS-LIBRARY-SCH-DECALS-V9*

PS1240P02BT 33300 33900 97 10 97 10 4 2 0 2 0
TIMESTAMP 2022.11.14.10.14.19
"Default Font"
"Default Font"
450   0     0 8 97 10 "Default Font"
REF-DES
450   -100  0 8 97 10 "Default Font"
PART-TYPE
450   -200  0 8 97 10 "Default Font"
*
450   -300  0 8 97 10 "Default Font"
*
OPEN   6 10 0 -1
200   50   
280   50   
380   150  
380   -250 
280   -150 
200   -150 
OPEN   2 10 0 -1
200   50   
200   -150 
T0     0     0 0 140   20    0 2 210   0     0 16 PIN
P-520  0     0 2 -80   0     0 2 0
T0     -100  0 0 140   20    0 2 210   0     0 16 PIN
P-520  0     0 2 -80   0     0 2 0


*END*